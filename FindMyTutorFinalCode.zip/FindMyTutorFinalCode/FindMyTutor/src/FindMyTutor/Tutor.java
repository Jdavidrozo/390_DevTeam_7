/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FindMyTutor;

/**
 *
 * @author Kaylee Springer
 */
public class Tutor {
    
        private String info;
        private String course;
        private String inTime;
        private String onTime;
        private String contact;
        private String onspc;
       // private String capacity;

    public Tutor(String n/*String c, String in, String on, String contact, String space*/) 
{
        this.info = n;
        /*this.course = c;
        this.inTime = in;
        this.onTime = on;
        this.contact = contact;
        this.onspc = space;
        //this.capacity = cap;*/
} 

    /**
     * @return the name
     */
    public String getName() {
        return info;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.info = name;
    }

    /**
     * @return the course
     
    public String getCourse() {
        return course;
    }

    /**
     * @param course the course to set
    
    public void setCourse(String course) {
        this.course = course;
    }

    /**
     * @return the inTime
     
    public String getInTime() {
        return inTime;
    }

    /**
     * @param inTime the inTime to set
     
    public void setInTime(String inTime) {
        this.inTime = inTime;
    }

    /**
     * @return the onTime
     
    public String getOnTime() {
        return onTime;
    }

    /**
     * @param onTime the onTime to set
     
    public void setOnTime(String onTime) {
        this.onTime = onTime;
    }

    /**
     * @return the contact
     
    public String getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     
    public void setContact(String contact) {
        this.contact = contact;
    }

    /**
     * @return the onspc
     
    public String getOnspc() {
        return onspc;
    }

    /**
     * @param onspc the onspc to set
     
    public void setOnspc(String onspc) {
        this.onspc = onspc;
    }

    /**
     * @return the capacity
     
    public String getCapacity() {
        return capacity;
    }

    /**
     * @param capacity the capacity to set
     
    public void setCapacity(String capacity) {
        this.capacity = capacity;
    } */
    
    
    public String toString() {
        
        return info /*+ "\n" + course + "\n" + inTime + "\n" + onTime + "\n" + contact + "\n" + onspc*/;
        
          
    }
    
}
