/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FindMyTutor;

/**
 *
 * @author Kaylee Springer
 */
public class InPersonTime {
     private String inPersonTime;
     
      public InPersonTime(String inTime) {
        this.inPersonTime = inTime;
      }

   
    public String getinTime() {
        return inPersonTime;
    }

    public void setinTime(String inTime) {
        this.inPersonTime = inTime;
    }
    
    public String toString() {
        
        return inPersonTime;
     
    }
    


}
