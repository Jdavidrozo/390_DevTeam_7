/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FindMyTutor;

/**
 *Author: Kaylee Springer
 * 
 */
public class User /*implements Comparable <User>*/ {
    ///private String name;
    private String username;
    private String password;
    
    public User() {
        //name = null;
        username = null;
        password = null;
    }
    
    public User(String user, String pass) {
        //name = n;
        username = user;
        password = pass;
    }

//    /**
//     * @return the name
//     */
//    public String getName() {
//        return name;
//    }
//
//    /**
//     * @param name the name to set
//     */
//    public void setName(String n) {
//        this.name = n;
//    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String user) {
        this.username = user;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String pass) {
        this.password = pass;
    }
    
    public String toString() {
        return username + "\n" + password;
    }
    
    /* public int compareTo (User b)
            { return this.username.compareTo(b.username);
            } */
    
    public boolean hasSameLogin(User b) {
        return this.username == b.username && this.password == b.password;
    }
}
