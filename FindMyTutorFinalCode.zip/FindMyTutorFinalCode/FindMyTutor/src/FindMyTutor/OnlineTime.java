/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FindMyTutor;

/**
 *
 * @author Kaylee Springer
 */
public class OnlineTime {
     private String onlineTime;
     
      public OnlineTime(String onTime) {
        this.onlineTime = onTime;
      }

   
    public String getOntime() {
        return onlineTime;
    }

    public void setOntime(String onTime) {
        this.onlineTime = onTime;
    }
    
    public String toString() {
        
        return onlineTime;
     
    }
    

}
