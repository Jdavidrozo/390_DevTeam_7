/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FindMyTutor;

/**
 *
 * @author Kaylee Springer
 */
public class OnlineSpace {
    private String onSpc;
     
      public OnlineSpace(String space) {
        this.onSpc = space;
      }

   
    public String getOnlineSpace() {
        return onSpc;
    }

    public void setOnlineSpace(String space) {
        this.onSpc = space;
    }
    
    public String toString() {
        
        return onSpc;
     
    }
}
