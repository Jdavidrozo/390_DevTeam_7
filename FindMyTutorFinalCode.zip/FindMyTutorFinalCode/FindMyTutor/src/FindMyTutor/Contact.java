/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FindMyTutor;

/**
 *
 * @author Kaylee Springer
 */
public class Contact {
     private String contact;
     
      public Contact(String contact) {
        this.contact = contact;
      }

   
    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }
    
    public String toString() {
        
        return contact;
     
    }
    

}
