/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package FindMyTutor;

/**
 *
 *
 */
public class FindMyTutor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //test code
  /*      
jList1 = new javax.swing.JList<>();

jList1.setModel(new javax.swing.AbstractListModel<String>() {
    //Arrays from database

    String[] course_Name = {"CMPSC-206 Web Applications 1", "CMPSC-306 Web Applications 2", "CMPSC-255 Introduction to Networks", "CMPSC-200 Virtual Worlds", "CMPSC-202 Programming I ", "CMPSC-203 Programming II", "CMPSC-345 Computer Systems & Organization", "CMPSC-311 Data Structures & Algorithms", "MATH-200 Discrete Mathematics", "RELST-266 Suffering & Death", "CMPSC-390 Software Engineering", "CMPSC-309 Issues in Computing", "BIOL-117 Exercise Physiology", "CMPSC-321 Databases", "ART-119 Digital Imagery", "Comms 221 Digital Video Production", "MATH-135 Introduction to Statistics", "ART-111 Intro to Film Analysis", "CMPSC-301 Operating Systems", "ART 220: Graphic Design II", "COMM-205 Mediated Message Production", "ART 322: Advertising in Marketing", "BIOL 213: Interactions in the Environment", "CMPSC-360 Usability and Design", "CHEM 331: Physical Chemistry", "PSYCH-101 Introduction to Psychology", "CHEM-111 General Chemistry", "MATH 202: Calculus with Analytic Geometry", "HIST-103 U.S. History to 1877", "COMM 220: Digital Audio Production", "Psych-200 child development", "Psych-199 lifespan development", "Psych-204 abnormal psychology", "MKTG 355 Digital Marketing", "BIOL-206 microbiology", "MGMT 370 IT Management", "BIOL-202 Human Anatomy", "ENGL 208: Study of Rhetoric", "BIOL-203 Human physiology", "CMPSC-260 Clojure"};

    //String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
    public int getSize() { return course_Name.length; }
    public String getElementAt(int i) { return course_Name[i]; }
});

jScrollPane1.setViewportView(jList1);
*/
    }
    
}
