/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FindMyTutor;

/**
 *
 * @author Kaylee Springer
 */
public class TutorName {
    
     private String name;
     private String course;
     private String intime;
     private String ontime;
     private String contact;
     private String space;
     
      public TutorName(String n,String crs, String in, String on,String con,String spc) {
        this.name = n;
        this.course = crs;
        this.intime = in;
        this.ontime = on;
        this.contact = con;
        this.space = spc;
      }

   
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    

    /**
     * @return the course
     */
    public String getCourse() {
        return course;
    }

    /**
     * @param course the course to set
     */
    public void setCourse(String course) {
        this.course = course;
    }

    /**
     * @return the intime
     */
    public String getIntime() {
        return intime;
    }

    /**
     * @param intime the intime to set
     */
    public void setIntime(String intime) {
        this.intime = intime;
    }

    /**
     * @return the ontime
     */
    public String getOntime() {
        return ontime;
    }

    /**
     * @param ontime the ontime to set
     */
    public void setOntime(String ontime) {
        this.ontime = ontime;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }

    /**
     * @return the space
     */
    public String getSpace() {
        return space;
    }

    /**
     * @param space the space to set
     */
    public void setSpace(String space) {
        this.space = space;
    }
    
     public String toString() {
        
        return name + course + intime + ontime + contact + space;
     
    }
    
}
