
package fmtappts;
import java.io.*;
import java.util.*;

public class Fmtappts {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
